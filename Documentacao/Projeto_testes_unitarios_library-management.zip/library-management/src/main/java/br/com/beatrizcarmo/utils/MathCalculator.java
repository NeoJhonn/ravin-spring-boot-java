package br.com.beatrizcarmo.utils;

public class MathCalculator {

    public int add(int x, int y) {
        return Math.addExact(x, y);
    }
}
