package br.com.beatrizcarmo.dto;

public class LibraryDto {

	public String id;
	public String name;
	public String adress;
	public Integer contact;
}
