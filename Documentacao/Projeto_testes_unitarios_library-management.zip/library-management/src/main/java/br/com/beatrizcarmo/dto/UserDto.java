package br.com.beatrizcarmo.dto;

public class UserDto {

	public String id;
	public String name;
    public String username;
    public String password;
    public boolean isPunished;
}
