insert into library (id, name, username, password, adress, contact) 
values ('0cbce1c3-fd6f-41c5-9f89-f515942bba07', 'Teste', 'Teste123', '123', 'Rua do Teste', 9999);